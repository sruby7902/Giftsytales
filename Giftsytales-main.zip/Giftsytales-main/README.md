# Giftsytales
A personalised gifts website featuring Polaroids, custom magazines, hampers, and handmade creations. Thoughtfully crafted to make every occasion special with unique, customised gifts
